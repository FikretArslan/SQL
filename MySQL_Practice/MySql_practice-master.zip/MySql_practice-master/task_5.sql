/*
 bolumler  tablosu --> bolum_id, bolum_isim, konum      
       
10,'MUHASABE','IST'
20,'MUDURLUK','ANKARA'
30,'SATIS','IZMIR'
40,'ISLETME','BURSA'
50,'DEPO', 'YOZGAT'
    
​ 
personel tablosu --> personel_id, personel_pk, personel_isim, meslek, mudur_id, ise_baslama, maas, bolum_id      
    
7369,'AHMET','KATIP',7902,'17-12-1980',800,20
7499,'BAHATTIN','SATIS',7698,'20-2-1981',1600,30
7521,'NESE','SATIS',7698,'22-2-1981',1250,30
7566,'MUZAFFER','MUDUR',7839,'2-4-1981',2975,20
7654,'MUHAMMET','SATIS',7698,'28-9-1981',1250,30
7698,'EMINE','MUDUR',7839,'1-5-1981',2850,30
7782,'HARUN','MUDUR',7839,'9-6-1981', 2450,10
7788,'MESUT','ANALIST',7566,'13-07-87',3000,20
7839,'SEHER','BASKAN',NULL,'17-11-1981',5000,10
7844,'DUYGU','SATIS',7698,'8-9-1981',1500,30
7876,'ALI','KATIP',7788,'13-07-87',1100,20
7900,'MERVE','KATIP',7698,'3-12-1981',950,30
7902,'NAZLI','ANALIST',7566,'3-12-1981',3000,20
7934,'EBRU','KATIP',7782,'23-1-1982',1300,10
7956,'SIBEL','MIMAR',7782,'29-1-1991',3300,60
7933,'ZEKI','MUHENDIS',7782,'26-1-1987',4300,60
      create ediniz...
 */
​
 /* -----------------------------------------------------------------------------
  ORNEK1: SATIS ve MUHASABE bolumlerinde calisan personelin isimlerini ve 
  bolumlerini, once bolum sonra isim sıralı olarak listeleyiniz
------------------------------------------------------------------------------*/ 
​
	
​
  
/* -----------------------------------------------------------------------------
  ORNEK2: SATIS,ISLETME ve DEPO bolumlerinde calisan personelin isimlerini,  
  bolumlerini ve ise_baslama tarihlerini isim sıralı olarak listeleyiniz. 
  NOT: calisani olmasa bile bolum ismi gosterilmelidir.
------------------------------------------------------------------------------*/  
​
	