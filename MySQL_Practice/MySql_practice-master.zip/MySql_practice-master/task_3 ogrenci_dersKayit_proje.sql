-- bir üniversite ders kaydi db si tasarlanmak isteniyor.
-- öğrencilerin adi, soyadi, email, telefon, bölüm  bilgisi vardir.  
-- bu öğrencilere ders saati belli olan dersler kaydedilecektir.
-- bu bilgileri kaydedilmesini sağlayan veri tabanini tasarlayiniz...



-- -----------------------------------------------------------------------------

-- soru : öğrencilerin bölümlerini listeleyiniz.


-- soru :  hangi bölümden kaç ders kaydi olduğunu bulunuz.


-- soru :  hangi dersten kaç öğrenci kaydi olduğunu bulunuz.


-- soru :  herhangi bir derse kayitli olmayan öğrenci listesini yazdiriniz

-- soru : hangi öğrencinin kaç derse kayit yaptirdiğini bulunuz.
-- soru : her bölümün kayitli olan toplam ders saatini bulunuz.
-- soru : en yüksek ders saatine sahip bölümü bulunuz.




